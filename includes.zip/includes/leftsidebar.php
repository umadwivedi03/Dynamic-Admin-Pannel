            <?php 
include '../OnlineJobPortal/constants/settings.php'; 
include '../OnlineJobPortal/constants/check-login.php';
?>
            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <ul>
                        	<li class="menu-title">Navigation</li>

                            <li class="has_sub">
                                <a href="dashboard.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Dashboard </span> </a>
                         
                            </li>
<?php if($_SESSION['utype']=='1'):?>
  <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Sub-admins </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-subadmins.php">Add Sub-admin</a></li>
                                    <li><a href="manage-subadmins.php">Manage Sub-admin</a></li>
                                </ul>
                            </li>
<?php endif;?>
                <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Job Portel</span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<li><a  href="../OnlineJobPortal/login.php">login</a></li>
							<li><a data-toggle="modal" href="../OnlineJobPortal/register.php?p=Employer">register</a></li>
                                </ul>
                            </li>
<li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Home</span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<li><a href="add-Home.php">Add Home</a></li>
                                    <li><a href="manage-Home.php">Manage Home</a></li>
                                </ul>
                            </li>
                             <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Poster</span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<li><a href="add-Poster.php">Add Poster</a></li>
                                    <li><a href="manage-Poster.php">Manage Poster</a></li>
                                </ul>
                            </li>
 <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> About Us </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                   
                                    <li><a href="add-about.php">Add Our Quality Policy</a></li>
                                    <li><a href="manage-about.php">Manage Our Quality Policy</a></li>
                                     <li><a href="add-global.php">Add Our Global Presence</a></li>
                                    <li><a href="manage-global.php">Manage Our Global Presence</a></li>
                                    <li><a href="add-History.php">Add Our History</a></li>
                                    <li><a href="manage-History.php">Manage Our History</a></li>
                                     <li><a href="add-Team.php">Add Our Team</a></li>
                                    <li><a href="manage-Team.php">Manage Our Team</a></li>
                                    <li><a href="add-Our Satellite Centers.php">Add Our Satellite Centers</a></li>
                                    <li><a href="manage-Our Satellite Centers.php">Manage Our Satellite Centers</a></li>
                                    <li><a href="add-all.php">Add Accreditations,Our Sister Concerns,Our Satellite Centers,Committee,Mission Vision And Values,Affiation And Recognition</a></li>
                                    <li><a href="manage-all.php">Manage Accreditations,Our Sister Concerns,Our Satellite Centers,Committee,Mission Vision And Values,Affiation And Recognition</a></li>
                                     </ul>
                            </li>
                             <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>News & Updates</span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-BMW.php">Add Public Information</a></li>
                                    <li><a href="manage-BMW.php">Manage Public Information</a></li>
                                    <li><a href="add-Testimonial.php">Add Testimonial</a></li>
                                    <li><a href="manage-Testimonial.php">Manage Testimonial</a></li>
                                   </ul>
                            </li>
                             <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Resourcess</span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                   <li><a href="add-event.php">Add Blog/Video/Audio </a></li>
                                   <li><a href="manage-blog.php">Manage Blog</a></li>
                                   <li><a href="manage-Video.php">Manage Video</a></li>
                                   <li><a href="manage-Audio.php">Manage Audio</a></li>
                                   <li><a href="gallery/index.php">Manage Gallery</a></li>
                                   <!--<li><a href="manage-gallery.php">Manage Gallery</a></li>-->
                                   </ul>
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Category </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<li><a href="add-category.php">Add Category</a></li>
                                    <li><a href="manage-categories.php">Manage Category</a></li>
                                </ul>
                            </li>

    <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Sub Category </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-subcategory.php">Add Sub Category</a></li>
                                    <li><a href="manage-subcategories.php">Manage Sub Category</a></li>
                                </ul>
                            </li>               
  <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Posts (News) </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-post.php">Add Posts</a></li>
                                    <li><a href="manage-posts.php">Manage Posts</a></li>
                                     <li><a href="trash-posts.php">Trash Posts</a></li>
                                </ul>
                            </li>  
                     

                            <!--<li class="has_sub">-->
                            <!--    <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Pages </span> <span class="menu-arrow"></span></a>-->
                            <!--    <ul class="list-unstyled">-->
                            <!--        <li><a href="aboutus.php">About us</a></li>-->
                            <!--        <li><a href="contact.php">Contact us</a></li>-->
                            <!--          <li><a href="gallery">Gallery</a></li>-->
                            <!--    </ul>-->
                            <!--</li>-->
                             <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Patient</span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-Patient.php">Add Patient Pages</a></li>
                                    <li><a href="manage-Patient.php">Manage Patient Pages</a></li>
                                      </ul>
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Academics</span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-Academics.php">Add Academics</a></li>
                                    <li><a href="manage-Academics.php">Manage Academics</a></li>
                                      </ul>
                            </li>
   <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Comments </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                  <li><a href="unapprove-comment.php">Waiting for Approval </a></li>
                                    <li><a href="manage-comments.php">Approved Comments</a></li>
                                </ul>
                            </li>   
<li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Doctor's</span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<li><a href="add-doctor.php">Add Doctor's</a></li>
                                    <li><a href="manage-doctor.php">Manage Doctor's</a></li>
                                     </ul>
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Department's</span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<li><a href="add-department.php">Add Department</a></li>
                                    <li><a href="manage-department.php">Manage Department</a></li>
                                    <li><a href="add-dep_doctor.php">Add Department Doctor's</a></li>
                                    <li><a href="manage-dep_doctor.php">Manage Department Doctor's</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                    <div class="help-box">
                        <h5 class="text-muted m-t-0">For Help ?</h5>
                        <p class=""><span class="text-custom">Email:</span> <br/> namastetu@gmail.com</p>
                    </div>

                </div>
                <!-- Sidebar -left -->

            </div>
            