<?php
define('DB_SERVER','localhost');
define('DB_USER','u273265295_choithramNew');
define('DB_PASS' ,'Diamond@5');
define('DB_NAME','u273265295_choithramNew');
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
// Check connection
if (mysqli_connect_errno())
{
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>