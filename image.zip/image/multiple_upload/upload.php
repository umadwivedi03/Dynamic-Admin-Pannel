<?php
	include('conn.php');
	$posttitle=$_POST['posttitle'];
	foreach ($_FILES['upload']['name'] as $key => $name){
		
		$newFilename = time() . "_" . $name;
		move_uploaded_file($_FILES['upload']['tmp_name'][$key], 'upload/' . $newFilename);
		$location = 'upload/' . $newFilename;
		
		mysqli_query($conn,"insert into photo (posttitle,location) values ('$posttitle','$location')");
	}
	header('location:../../add-gallery.php');
?>

