<?php
 
//MySQLi Procedural
$conn = mysqli_connect("localhost","u273265295_choithramNew","Diamond@5","u273265295_choithramNew");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
 
?>